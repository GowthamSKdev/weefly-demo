function ExploreAfrica() {
  return <div className="">ExploreAfrica</div>;
}

export default ExploreAfrica;
