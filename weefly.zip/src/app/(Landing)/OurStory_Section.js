function OurStory_Section() {
  return <div>OurStory_Section</div>;
}

export default OurStory_Section;
