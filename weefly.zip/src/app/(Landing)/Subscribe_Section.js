function Subscribe_Section() {
  return <div>Subscribe_Section</div>;
}

export default Subscribe_Section;
